"""
llamdrop - doctor.py
Diagnoses your llamdrop install and device setup.
Run via: llamdrop doctor  OR from the main menu.

Checks:
- llama-cli binary present and executable
- LD_LIBRARY_PATH / .so libraries in bin/
- Available RAM vs minimum needed
- Free storage space
- sessions/ and models/ directories writable
- models.json present and valid
- GitHub reachable (network check)
- Python version
- Termux storage permission
"""

import os
import sys
import json
import subprocess
import urllib.request


LLAMDROP_DIR = os.path.expanduser("~/.llamdrop")
BIN_DIR      = os.path.join(LLAMDROP_DIR, "bin")
MODELS_DIR   = os.path.join(LLAMDROP_DIR, "models")
SESSIONS_DIR = os.path.join(LLAMDROP_DIR, "sessions")
MODELS_JSON  = os.path.join(LLAMDROP_DIR, "models.json")
GITHUB_CHECK = "https://raw.githubusercontent.com/DeVenLucaz/llamdrop/main/llamdrop.py"

GREEN  = "\033[32m"
YELLOW = "\033[33m"
RED    = "\033[31m"
CYAN   = "\033[36m"
BOLD   = "\033[1m"
RESET  = "\033[0m"


def _ok(label, detail=""):
    d = f"  {detail}" if detail else ""
    print(f"  {GREEN}✓{RESET}  {label}{d}")


def _warn(label, detail="", fix=""):
    d = f"  {detail}" if detail else ""
    print(f"  {YELLOW}⚠{RESET}  {label}{d}")
    if fix:
        print(f"     → {fix}")


def _fail(label, detail="", fix=""):
    d = f"  {detail}" if detail else ""
    print(f"  {RED}✗{RESET}  {label}{d}")
    if fix:
        print(f"     → {fix}")


def _section(title):
    print(f"\n  {BOLD}{CYAN}{title}{RESET}")
    print(f"  {'─' * 40}")


def check_binary():
    _section("llama.cpp Binary")

    cli_path = os.path.join(BIN_DIR, "llama-cli")
    binary   = cli_path if os.path.isfile(cli_path) else None

    if binary:
        if os.access(binary, os.X_OK):
            _ok("llama-cli found", binary)
        else:
            _fail("llama-cli not executable",
                  fix="chmod +x ~/.llamdrop/bin/llama-cli")
            return False
    else:
        import shutil
        sys_cli = shutil.which("llama-cli")
        if sys_cli:
            binary = sys_cli
            _ok("llama-cli found (system)", sys_cli)
        else:
            _fail("llama-cli not found",
                  fix="Re-run the installer: curl -sL https://raw.githubusercontent.com/DeVenLucaz/llamdrop/main/install.sh | bash")
            return False

    # Check .so libraries
    so_files = []
    if os.path.isdir(BIN_DIR):
        so_files = [f for f in os.listdir(BIN_DIR) if f.endswith(".so")]
    if so_files:
        _ok(f"Libraries found", f"({len(so_files)} .so files in bin/)")
    else:
        _warn("No .so libraries in bin/",
              fix="May work with system libs — test by running llamdrop and chatting")

    # Binary version check — capture stderr to show real errors
    try:
        env = os.environ.copy()
        env["LD_LIBRARY_PATH"] = BIN_DIR + ":" + env.get("LD_LIBRARY_PATH", "")
        result = subprocess.run(
            [binary, "--version"],
            capture_output=True, timeout=5, env=env, text=True
        )
        if result.returncode == 0:
            version_line = (result.stdout or result.stderr or "").splitlines()
            ver_str = version_line[0].strip() if version_line else "unknown"
            _ok(f"llama-cli version: {ver_str}")
        else:
            _fail("llama-cli --version returned non-zero")
            # Show actual stderr so user sees missing .so or arch mismatch
            if result.stderr:
                for ln in result.stderr.strip().splitlines()[-5:]:
                    print(f"     {RED}{ln}{RESET}")
    except subprocess.TimeoutExpired:
        _warn("llama-cli version check timed out (may still work)")
    except Exception as e:
        _fail("llama-cli failed to run", fix=str(e))
        return False

    # Self-test: run a tiny inference to confirm binary actually works end-to-end
    # (binary present + executable ≠ working — missing .so or wrong arch will fail here)
    try:
        env = os.environ.copy()
        env["LD_LIBRARY_PATH"] = BIN_DIR + ":" + env.get("LD_LIBRARY_PATH", "")
        result = subprocess.run(
            [binary, "--help"],
            capture_output=True, timeout=8, env=env, text=True
        )
        if result.returncode == 0 or "--model" in (result.stdout + result.stderr):
            _ok("llama-cli self-test passed (--help responds)")
        else:
            _warn("llama-cli --help returned unexpected output")
            if result.stderr:
                for ln in result.stderr.strip().splitlines()[-3:]:
                    print(f"     {YELLOW}{ln}{RESET}")
    except subprocess.TimeoutExpired:
        _warn("llama-cli self-test timed out")
    except Exception as e:
        _fail("llama-cli self-test failed", str(e),
              fix="Binary may be corrupted or wrong architecture — re-run installer")
        return False

    return True


def check_ram():
    _section("RAM")
    try:
        with open("/proc/meminfo") as f:
            lines = f.readlines()

        info = {}
        for line in lines:
            parts = line.split()
            if len(parts) >= 2:
                info[parts[0].rstrip(":")] = int(parts[1])

        total_kb    = info.get("MemTotal",     0)
        avail_kb    = info.get("MemAvailable", 0)
        swap_tot_kb = info.get("SwapTotal",    0)
        swap_free_kb= info.get("SwapFree",     0)
        total_gb    = round(total_kb     / 1024 / 1024, 1)
        avail_gb    = round(avail_kb     / 1024 / 1024, 2)
        used_gb     = round(total_gb - avail_gb, 1)

        print(f"  Total    : {total_gb} GB")
        print(f"  Used     : {used_gb} GB")
        print(f"  Free     : {avail_gb} GB")

        # zram / swap info — relevant on Android where zram meaningfully extends RAM
        if swap_tot_kb > 0:
            swap_tot_gb  = round(swap_tot_kb  / 1024 / 1024, 1)
            swap_free_gb = round(swap_free_kb / 1024 / 1024, 1)
            swap_used_gb = round(swap_tot_gb - swap_free_gb, 1)
            # Detect zram vs real swap (zram devices are usually < 4GB)
            swap_type = "zram" if swap_tot_gb < 4.0 else "swap"
            print(f"  {swap_type.capitalize():<9}: {swap_free_gb} GB free / {swap_tot_gb} GB total  "
                  f"({swap_used_gb} GB used)")
            if swap_type == "zram":
                effective_gb = round(avail_gb + swap_free_gb * 0.6, 1)
                print(f"  Effective: ~{effective_gb} GB  (RAM + 60% zram weight)")

        if avail_gb < 0.8:
            _fail("Critical — less than 0.8 GB free",
                  fix="Close other apps before chatting")
        elif avail_gb < 1.5:
            _warn("Low RAM — only Tier 1 models recommended",
                  fix="Close background apps to free more RAM")
        elif avail_gb < 3.0:
            _ok("RAM OK — Tier 1 and Tier 2 models available")
        else:
            _ok("RAM good — all tiers available")

        return avail_gb

    except Exception as e:
        _fail("Could not read RAM info", str(e))
        return 0.0


def check_storage():
    _section("Storage")
    try:
        stat     = os.statvfs(LLAMDROP_DIR)
        free_gb  = round(stat.f_bavail * stat.f_frsize / 1024**3, 1)
        total_gb = round(stat.f_blocks * stat.f_frsize / 1024**3, 1)

        print(f"  Free     : {free_gb} GB")
        print(f"  Total    : {total_gb} GB")

        # Count downloaded models
        model_files = []
        if os.path.isdir(MODELS_DIR):
            model_files = [f for f in os.listdir(MODELS_DIR) if f.endswith(".gguf")]
        if model_files:
            total_size = sum(
                os.path.getsize(os.path.join(MODELS_DIR, f))
                for f in model_files
            )
            print(f"  Models   : {len(model_files)} downloaded ({round(total_size/1024**3, 1)}GB)")

        if free_gb < 0.5:
            _fail("Critical — less than 0.5GB free",
                  fix="Delete old models: go to My downloaded models")
        elif free_gb < 2.0:
            _warn("Low storage — may not fit new models",
                  fix="Free up space before downloading Tier 2/3 models")
        else:
            _ok("Storage OK")

        return free_gb

    except Exception as e:
        _fail("Could not check storage", str(e))
        return 0.0


def check_directories():
    _section("Install Directories")

    dirs = {
        "Install dir":  LLAMDROP_DIR,
        "Models dir":   MODELS_DIR,
        "Sessions dir": SESSIONS_DIR,
        "Binary dir":   BIN_DIR,
    }

    all_ok = True
    for label, path in dirs.items():
        if os.path.isdir(path):
            # Test write permission
            test_file = os.path.join(path, ".write_test")
            try:
                with open(test_file, "w") as f:
                    f.write("test")
                os.remove(test_file)
                _ok(label, path)
            except Exception:
                _fail(f"{label} not writable", path,
                      fix=f"chmod 755 {path}")
                all_ok = False
        else:
            try:
                os.makedirs(path, exist_ok=True)
                _ok(f"{label} created", path)
            except Exception:
                _fail(f"{label} missing and could not create", path)
                all_ok = False

    return all_ok


def check_models_json():
    _section("Model Catalog")

    if not os.path.exists(MODELS_JSON):
        _fail("models.json not found",
              fix="Run: curl -sL https://raw.githubusercontent.com/DeVenLucaz/llamdrop/main/models.json -o ~/.llamdrop/models.json")
        return False

    try:
        with open(MODELS_JSON) as f:
            data = json.load(f)

        version = data.get("version", "unknown")
        models  = data.get("models", [])
        updated = data.get("last_updated", "unknown")

        _ok(f"models.json valid — v{version}, {len(models)} models, updated {updated}")
        return True

    except json.JSONDecodeError as e:
        _fail("models.json is corrupted", str(e),
              fix="Re-download: curl -sL https://raw.githubusercontent.com/DeVenLucaz/llamdrop/main/models.json -o ~/.llamdrop/models.json")
        return False


def check_network():
    _section("Network")

    github_ok = False
    hf_ok     = False

    # GitHub
    try:
        req = urllib.request.Request(
            GITHUB_CHECK,
            headers={"User-Agent": "llamdrop-doctor/0.5"}
        )
        with urllib.request.urlopen(req, timeout=8) as r:
            r.read(100)
        _ok("GitHub reachable (updates/install work)")
        github_ok = True
    except Exception as e:
        _fail("Cannot reach GitHub", str(e),
              fix="Updates and installer won't work — check your connection")

    # HuggingFace — separate check since models come from here
    try:
        req = urllib.request.Request(
            "https://huggingface.co/api/models?limit=1",
            headers={"User-Agent": "llamdrop-doctor/0.5"}
        )
        with urllib.request.urlopen(req, timeout=8) as r:
            r.read(100)
        _ok("HuggingFace reachable (model downloads/search work)")
        hf_ok = True
    except Exception as e:
        _fail("Cannot reach HuggingFace", str(e),
              fix="Model downloads and HF search won't work — check connection or VPN")

    return github_ok, hf_ok


def check_python():
    _section("Python")

    ver = sys.version_info
    ver_str = f"{ver.major}.{ver.minor}.{ver.micro}"

    if ver.major < 3 or (ver.major == 3 and ver.minor < 8):
        _fail(f"Python {ver_str} — too old (need 3.8+)",
              fix="pkg install python")
    else:
        _ok(f"Python {ver_str}")

    # Check curses
    try:
        import curses
        _ok("curses module available")
    except ImportError:
        _fail("curses not available",
              fix="pkg install python")

    return ver.major == 3 and ver.minor >= 8


def check_termux_storage():
    _section("Termux Storage")

    shared = os.path.expanduser("~/storage/shared")
    if os.path.isdir(shared):
        _ok("Storage permission granted", shared)
        dl = os.path.join(shared, "Download")
        if os.path.isdir(dl):
            _ok("Downloads folder accessible", dl)
        else:
            _warn("Download folder not found inside storage/shared")
        return True
    else:
        _warn(
            "Storage permission not granted",
            detail="  Model scanning, chat export to Downloads, and external GGUF detection won't work.",
            fix="Run: termux-setup-storage  (then restart Termux)"
        )
        return False


def check_partial_downloads():
    _section("Model Files")

    if not os.path.isdir(MODELS_DIR):
        print(f"  Models directory not found — no models downloaded yet.")
        return True

    all_gguf = [f for f in os.listdir(MODELS_DIR) if f.endswith(".gguf")]
    if not all_gguf:
        print(f"  No models downloaded yet.")
        return True

    MIN_VALID = 50 * 1024 * 1024  # 50 MB
    good, partial = [], []
    for fname in all_gguf:
        fpath = os.path.join(MODELS_DIR, fname)
        size  = os.path.getsize(fpath)
        if size < MIN_VALID:
            partial.append((fname, size))
        else:
            good.append((fname, size))

    for fname, size in good:
        size_gb = round(size / 1024**3, 2)
        _ok(f"{fname}", f"({size_gb} GB)")

    for fname, size in partial:
        size_mb = round(size / 1024**2, 1)
        _warn(
            f"Partial/incomplete: {fname}",
            detail=f"  Only {size_mb} MB — cancelled or interrupted download.",
            fix=f"Re-download to resume, or delete manually: rm ~/.llamdrop/models/{fname}"
        )

    return len(partial) == 0


def check_config():
    _section("Config Validation")

    config_file = os.path.join(LLAMDROP_DIR, "config.json")
    if not os.path.exists(config_file):
        print(f"  No config.json — using all auto-detected defaults. (This is fine.)")
        return True

    try:
        with open(config_file) as f:
            raw = json.load(f)
    except json.JSONDecodeError as e:
        _fail("config.json is corrupted — JSON parse error", str(e),
              fix=f"Delete and recreate: rm {config_file}")
        return False

    _ok("config.json is valid JSON")

    try:
        import sys as _sys
        import os as _os
        _sys.path.insert(0, _os.path.dirname(__file__))
        from config import CONFIG_SCHEMA
    except ImportError:
        _warn("Could not import CONFIG_SCHEMA — skipping value validation")
        return True

    issues = 0
    for key, val in raw.items():
        if key not in CONFIG_SCHEMA:
            _warn(f"Unknown key: '{key}'", fix="This key is ignored — check spelling")
            issues += 1
            continue
        schema = CONFIG_SCHEMA[key]
        try:
            coerced = schema["type"](val)
        except (ValueError, TypeError):
            _fail(f"'{key}' has wrong type — expected {schema['type'].__name__}",
                  fix=f"Fix or remove this key in {config_file}")
            issues += 1
            continue
        if "min" in schema and coerced < schema["min"]:
            _fail(f"'{key}' = {coerced} is below minimum ({schema['min']})",
                  fix=f"Set to at least {schema['min']} or remove the key")
            issues += 1
        elif "max" in schema and coerced > schema["max"]:
            _fail(f"'{key}' = {coerced} exceeds maximum ({schema['max']})",
                  fix=f"Set to at most {schema['max']} or remove the key")
            issues += 1
        else:
            _ok(f"'{key}' = {coerced}")

    if issues == 0:
        _ok("All config values valid")
    return issues == 0


def check_benchmarks():
    _section("Benchmarks")

    bench_file = os.path.join(LLAMDROP_DIR, "benchmarks.json")
    if not os.path.exists(bench_file):
        print(f"  No benchmarks recorded yet.")
        print(f"  Chat with a model to record your first benchmark.")
        return

    try:
        with open(bench_file) as f:
            data = json.load(f)

        if not data:
            print("  No benchmarks recorded yet.")
            return

        print(f"  {len(data)} model(s) benchmarked:\n")
        for filename, b in data.items():
            tps  = b.get("gen_tps", 0)
            runs = b.get("runs", 0)
            last = b.get("last_run", "")
            name = filename.replace(".gguf", "")[:40]
            print(f"  ⚡ {int(tps)} t/s  ·  {name}")
            print(f"     {runs} run(s) averaged  ·  last: {last}")
    except Exception as e:
        _warn("Could not read benchmarks.json", str(e))


# ── Main entry point ──────────────────────────────────────────────────────────

def check_ollama():
    """Check if Ollama is installed and running (optional backend)."""
    _section("Ollama Backend (optional)")
    try:
        from backends.ollama import get_info
        info = get_info()
    except ImportError:
        _warn("Ollama backend module not found", fix="Re-run llamdrop update")
        return None

    if not info["installed"]:
        _warn("Ollama not installed",
              fix="Install from https://ollama.com — needed only on Linux/desktop")
        return None

    _ok("Ollama installed", info.get("version", ""))

    if not info["running"]:
        _warn("Ollama server not running",
              fix="Run: ollama serve")
        return False

    _ok("Ollama server running", info["api_url"])

    models = info["models"]
    if models:
        _ok(f"Models pulled: {len(models)}", ", ".join(models[:3]) + ("..." if len(models) > 3 else ""))
    else:
        _warn("No models pulled yet", fix="Run: ollama pull qwen2.5:3b")

    return True


def cleanup_partial_downloads(interactive=True):
    """Scan and delete partial GGUF downloads under 50MB."""
    if not os.path.isdir(MODELS_DIR):
        return

    all_gguf = [f for f in os.listdir(MODELS_DIR) if f.endswith(".gguf")]
    MIN_VALID = 50 * 1024 * 1024
    partials = [f for f in all_gguf if os.path.getsize(os.path.join(MODELS_DIR, f)) < MIN_VALID]

    if not partials:
        if not interactive: return
        print(f"\n  {GREEN}✓ No partial downloads found.{RESET}")
        return

    print(f"\n  {YELLOW}Found {len(partials)} partial download(s):{RESET}")
    for p in partials:
        size_mb = round(os.path.getsize(os.path.join(MODELS_DIR, p)) / 1024 / 1024, 1)
        print(f"    • {p} ({size_mb} MB)")

    if interactive:
        try:
            choice = input(f"\n  Delete these {len(partials)} partial files? (y/N): ").strip().lower()
            if choice == "y":
                for p in partials:
                    os.remove(os.path.join(MODELS_DIR, p))
                print(f"  {GREEN}✓ Cleaned up {len(partials)} files.{RESET}")
            else:
                print("  Cleanup skipped.")
        except (EOFError, KeyboardInterrupt):
            print("\n  Cleanup cancelled.")
    else:
        # Non-interactive mode (e.g. called via flag)
        for p in partials:
            os.remove(os.path.join(MODELS_DIR, p))


def run_doctor():
    os.system("clear")
    print(f"\n  {BOLD}🦙 llamdrop doctor{RESET}")
    print(f"  Checking your install...\n")

    results = {}

    results["binary"]   = check_binary()
    results["ram"]      = check_ram()
    results["storage"]  = check_storage()
    results["dirs"]     = check_directories()
    results["catalog"]  = check_models_json()
    results["network"]  = check_network()   # now returns (github_ok, hf_ok) tuple
    results["python"]   = check_python()
    results["ollama"]   = check_ollama()
    results["termux"]   = check_termux_storage()
    results["models"]   = check_partial_downloads()
    results["config"]   = check_config()

    check_benchmarks()

    # Summary
    print(f"\n  {'─' * 42}")
    print(f"  {BOLD}Summary{RESET}\n")

    issues = []
    if not results.get("binary"):
        issues.append("llama-cli binary missing or broken — re-run installer")
    if isinstance(results.get("ram"), float) and results["ram"] < 0.8:
        issues.append("Critical RAM — close other apps before chatting")
    if isinstance(results.get("storage"), float) and results["storage"] < 0.5:
        issues.append("Critical storage — delete old models")
    if not results.get("dirs"):
        issues.append("Directory permission issues — check chmod on ~/.llamdrop")
    if not results.get("catalog"):
        issues.append("models.json missing or corrupted")
    # Network: results["network"] is now a tuple (github_ok, hf_ok)
    net = results.get("network")
    if isinstance(net, tuple):
        github_ok, hf_ok = net
        if not github_ok:
            issues.append("GitHub unreachable — updates/installer won't work")
        if not hf_ok:
            issues.append("HuggingFace unreachable — model downloads/search won't work")
    elif not net:
        issues.append("No network — downloads and updates won't work")
    if not results.get("python"):
        issues.append("Python version too old — upgrade to 3.8+")
    if results.get("ollama") is False:
        issues.append("Ollama installed but server not running — run: ollama serve")
    if not results.get("termux"):
        issues.append("Termux storage permission missing — run: termux-setup-storage")
    if not results.get("models"):
        issues.append("Partial/incomplete model files found — run 'llamdrop doctor --cleanup' to fix")
    if not results.get("config"):
        issues.append("config.json has invalid values — edit via Settings or delete the file")

    if not issues:
        print(f"  {GREEN}{BOLD}✓ Everything looks good!{RESET}")
        print(f"  llamdrop is healthy and ready to use.")
    if issues:
        print(f"  {YELLOW}Found {len(issues)} issue(s):{RESET}\\n")
        for i, issue in enumerate(issues, 1):
            print(f"  {i}. {issue}")
        print("\\n  Press 'F' to attempt auto-fix, or Enter to return.")
        try:
            # We need to read a char
            import sys, tty, termios
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(sys.stdin.fileno())
                ch = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            
            if ch.lower() == 'f':
                print("\\n  Attempting auto-fix...")
                if not results.get("binary"):
                    print("  Fixing binary...")
                    os.system("curl -s https://raw.githubusercontent.com/DeVenLucaz/llamdrop/main/install.sh | bash")
                if not results.get("dirs"):
                    print("  Fixing directories...")
                    os.makedirs(BIN_DIR, exist_ok=True)
                    os.makedirs(MODELS_DIR, exist_ok=True)
                    os.makedirs(SESSIONS_DIR, exist_ok=True)
                if not results.get("catalog"):
                    print("  Fixing models.json...")
                    os.system(f"curl -s https://raw.githubusercontent.com/DeVenLucaz/llamdrop/main/models.json -o {MODELS_JSON}")
                if not results.get("config"):
                    print("  Fixing config.json...")
                    os.system(f"rm -f {LLAMDROP_DIR}/config.json")
                if not results.get("termux"):
                    print("  Fixing termux storage...")
                    os.system("termux-setup-storage")
                print("  Auto-fix complete. Please re-run doctor to verify.\\n")
        except:
            pass

    print("")
